module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "pt"
};

/* module.exports = {
  HOST: "db4free.net",
  USER: "iamsupreme",
  PASSWORD: "New.db4free1",
  DB: "cryout"
}; */